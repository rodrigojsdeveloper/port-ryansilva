# Meu portfólio V2

## Descrição 💬	
Portfólio desenvolvido usando HTML, CSS, JS com o framework Django em python. Usando a hospedagem da AWS!


### Acesse o portfólio [clicando aqui](http://portryan-env-1.eba-r3mjces3.us-east-1.elasticbeanstalk.com/)
